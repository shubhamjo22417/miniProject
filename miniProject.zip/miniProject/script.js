/*$(document).ready(function(){


    $.ajax({
        type: 'GET',
        dataType: 'json',
        url: 'http://localhost:3000/data',
        success: function(res){
            console.log('onload get data')              
            $.each(res, function(i, v){
                console.log('Id: '+ v.id)
                $("#show").html( v.uname)
                
            })
        }
    })

   
    $('#getAddress').click(function(){
        $.ajax({
            type: 'GET',
            dataType: 'json',
            url: 'http://localhost:3000/data',
            success: function(res){
                console.log('successfully get data from json-server')              
                $.each(res, function(i, v){
                    $("#whole").html('---------------'+ i + '--------------')
                    $("#whole").html('Id: '+ v.id)
                    $("#whole").html('username: '+ v.uname)
                    // $("#whole").html('patta: '+v.add)
                })
            }
        })
    })
})


*/



var x = document.getElementById("lati");
var y = document.getElementById("longi");
function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
   } else { 
     x.innerHTML = "Geolocation is not supported by this browser.";
   }
}

function showPosition(position) {
    lati.innerHTML = position.coords.latitude ;
    longi.innerHTML = position.coords.longitude ;
}

